package com.blog.hwanseob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HwanseobApplication {

	public static void main(String[] args) {
		SpringApplication.run(HwanseobApplication.class, args);
	}

}
